# -*- coding: utf-8 -*-
"""
Created on Sat Sep 18 21:45:50 2021

@author: Mustafa
"""

queue = []

def parent(i):
    if i%2 != 0:
        return i//2
    
    return (i-1)//2

def left(i):
    return 2*i + 1

def right(i):
    return 2*i + 2

def min_heapify(A, i):
    l = left(i)
    r = right(i)
    smallest = i
    
    print("Left, Right, smallest index: ", l, r, smallest)
    
    if l <= (len(A) - 1) and A[l] < A[i]:
        smallest = l
    
    if r <= (len(A) - 1) and A[r] < A[smallest]:
        smallest = r
        
    if smallest != i:
        A[i], A[smallest] = A[smallest], A[i]
        min_heapify(A, smallest)
        
def insert(key):
    queue.append(key)
    i = len(queue) - 1
    while i > 0 and queue[parent(i)] > key:
        queue[i], queue[parent(i)] = queue[parent(i)], queue[i]
        i = parent(i)
        
def extract_min():
    """Removes the minimum element in the queue.

    Returns:
        The value of the removed element.
    """
    if len(queue) == 0:
        return None
    if len(queue) > 1:
        queue[0], queue[-1] = queue[-1], queue[0]
    min_element = queue.pop()
    min_heapify(queue, 0)
    return min_element